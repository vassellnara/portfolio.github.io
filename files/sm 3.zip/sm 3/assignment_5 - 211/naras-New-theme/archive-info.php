<?php 
get_header();
pageBanner(array(
  'title' => 'Understand us better',
  'subtitle' => 'Learn more about your new community'
));

?>
<!-- This was the old code for in between the h1 stuff.
 This one is good for specific titles-->
<?php //if (is_category()){
           // single_cat_title();}

            //if (is_author()) {
                //echo 'Posts by'; the_author();
            //} ?>

    <div class="container container--narrow page-section">
<?php



while(have_posts()){
  the_post();?>
  <div class="info-summary">
  <?php echo '<hr class="section-break">';?>
    <div class="info-summary__content">
      <h5 class="info-summary__title headline headline--tiny"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
      <p><?php echo wp_trim_words(get_the_content(), 18); ?> <a href="<?php the_permalink(); ?>" class="nu gray">Learn more</a></p>
    </div>
 </div>

<?php }
  echo paginate_links();

?>
</div>



<?php
get_footer();
?>