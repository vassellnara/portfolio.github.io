<?php 
get_header();
pageBanner(array(
  'title' => 'All Events',
  'subtitle' => 'See what is going on in our world.'
));
?>
<!-- This was the old code for in between the h1 stuff.
 This one is good for specific titles-->
<?php //if (is_category()){
           // single_cat_title();}

            //if (is_author()) {
                //echo 'Posts by'; the_author();
            //} ?>

    <div class="container container--narrow page-section">
<?php



while(have_posts()){
  the_post();
get_template_part('template-parts/content-event');
}
  echo paginate_links();

?>

<hr class="section-break">
<p>Looking for a recap of past events? <a href="<?php echo site_url('/past-events')?>">Check out our past events archive.</a></p>
</div>
</div>



<?php
get_footer();
?>