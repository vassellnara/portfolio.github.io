<?php 

//new function! //to remove the undefined warning add !isset
//also add AND there 
//also add ['url'] to indicate the url
function pageBanner($args = NULL) {

    if (!isset($args['title'])) {
      $args['title'] = get_the_title();
    }
   
    if (!isset($args['subtitle'])) {
      $args['subtitle'] = get_field('page_banner_subtitle');
    }
   
    if (!isset($args['photo'])) {
      if (get_field('page_banner_background_image') AND !is_archive() AND !is_home() ) {
        $args['photo'] = get_field('page_banner_background_image')['url']; //['sizes']['pageBanner'];
      } else {
        $args['photo'] = get_theme_file_uri('/images/header.jpg');
      }
    }
    
    ?>
 <div class="page-banner">
      <div class="page-banner__bg-image" style="background-image: url(<?php echo $args['photo']; ?>);"></div>
      <div class="page-banner__content container container--narrow">
        <h1 class="page-banner__title"><?php echo $args['title'] ?></h1>
        <div class="page-banner__intro">
          <p><?php echo $args['subtitle'] ?></p>
        </div>
      </div>
    </div>
 
<?php }

function university_files() {
    wp_enqueue_script('main-university-js', get_theme_file_uri('/build/index.js'), array('jquery'), '1.0', true);
    wp_enqueue_style('custom-google-fonts', 'https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400..700;1,400..700&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
    wp_enqueue_style('font-awesome', '//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
    wp_enqueue_style('university_main_styles', get_theme_file_uri('/build/style-index.css'));
    wp_enqueue_style('university_extra_styles', get_theme_file_uri('/build/index.css'));
}

add_action('wp_enqueue_scripts', 'university_files');

//new stuff added VV

function university_features () {
    register_nav_menu('headerMenuLocation', 'Header Menu Location');
	register_nav_menu('footerLocationOne', 'Footer Location One');
	register_nav_menu('footerLocationTwo', 'Footer Location Two');
    add_theme_support('title-tag');
}

//post types, add three
// https://developer.wordpress.org/resource/dashicons/#editor-paste-word to find icons

//don't need the bottom anymore VV check mu-plugins

// function university_post_types() {
//     register_post_type('event', array(
//         'public' => true,
//         'labels' => array(
//             'name' => 'Events'
//         ),
//         'menu_icon' => 'dashicons-calendar'
//     ));
// }


add_action('after_setup_theme', 'university_features');

if (!is_admin() AND is_post_type_archive('program') AND is_main_query()) {
    $query->set('orderby', 'title');
    $query->set('order', 'ASC');
    $query->set('posts_per_page', -1);
}

function university_adjust_queries($query) {

    if (! is_admin() AND is_post_type_archive('locations') AND $query->is_main_query()) {
        $query->set('orderby', 'title');
        $query->set('order', 'ASC');
        $query->set('posts_per_page', -1);
       }

   if (! is_admin() AND is_post_type_archive('event') AND $query->is_main_query()) {
    $today = date('Ymd');
    $query->set('meta_key', 'event_date');
    $query->set('orderby', 'meta_value_num');
    $query->set('order', 'ASC');
    $query->set('meta_query', array(
        array(
          'key' => 'event_date',
          'compare' => '>=',
          'value' => $today,
          'type' => 'numeric'
        )
       ));

   }
}


add_action('pre_get_posts', 'university_adjust_queries');
